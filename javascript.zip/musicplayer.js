class MusicPlayer{

    constructor(atualSong){
        this.atualSong = atualSong;
    }

    nextSong(otherSong){
        this.atualSong = otherSong;

    }

    displaySong(){
        console.log("The current song is: "+ this.atualSong);
    }

}

let atualSong = new MusicPlayer("Dear John - Taylor Swift");
atualSong.displaySong();
atualSong.nextSong("Back to December - Taylor Swift");
atualSong.displaySong();