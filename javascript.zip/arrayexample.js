let fruits=["banana", "orange", "apple"];

console.log(fruits.sort());

let myMap = fruits.map(element => {
    return "I like "+ element;
})

console.log(myMap);