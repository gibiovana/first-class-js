class Garage{
    constructor(myArray){
        this.myCars = myArray;
    }

    sortCars(){
        this.myCars.sort();
    }

    includeCar(car){
        console.log(this.myCars.includes(car));
        
    }

    displayCars(){
        this.myCars.map((element, index) =>{
            console.log("Car "+(index+1) +" is "+element);
        } )
    }
}

let cars = ["ferrari", "kombi","van escolar","caminhão"];
let garage = new Garage(cars);
garage.sortCars();
garage.includeCar("kombi");
garage.includeCar("stilo amarelo");

garage.displayCars();